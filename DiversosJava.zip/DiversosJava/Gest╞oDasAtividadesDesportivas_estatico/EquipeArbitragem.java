import java.util.List;

public class EquipeArbitragem {
    private List<Associado> arbitros;

    // Getters e Setters
    public List<Associado> getArbitros() {
        return arbitros;
    }

    public void setArbitros(List<Associado> arbitros) {
        this.arbitros = arbitros;
    }
}